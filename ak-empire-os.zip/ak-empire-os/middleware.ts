import { NextResponse, type NextRequest } from 'next/server'

export function middleware(request: NextRequest) {
  // Allow all requests through — auth is handled client-side
  // Supabase auth state is managed in the app layout
  return NextResponse.next()
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|api).*)'],
}
